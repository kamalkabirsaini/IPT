/* 
 * File:   Exception_Differenttype.c
 * Author: amank
 *
 * Created on 8 August, 2017, 10:44 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include<jni.h>
#include <string.h>
#include <ctype.h>
#include "exceptionheader.h"

/*
 * 
 */
JNIEXPORT jint JNICALL Java_exception_1difftypes_Exception_1Difftypes_intmethod
  (JNIEnv *env, jobject job, jint n)
{
    jint result;
    result=n*n;
    return result;
}

JNIEXPORT jboolean JNICALL Java_exception_1difftypes_Exception_1Difftypes_booleanmethod
  (JNIEnv *env, jobject job, jboolean bo)
{
   jboolean jbool;
    return jbool; 
}


JNIEXPORT jstring JNICALL Java_exception_1difftypes_Exception_1Difftypes_stringmethod
  (JNIEnv *env, jobject job, jstring strin)
{
    const char* str = (*env)->GetStringUTFChars(env,strin,NULL);
    char cap[10];
    strcpy(cap,str);
    (*env)->ReleaseStringUTFChars(env,strin, str);
    strupr(cap);
    return (*env)->NewStringUTF(env,cap);
}



JNIEXPORT void JNICALL Java_exception_1difftypes_Exception_1Difftypes_doit
  (JNIEnv *env, jobject jobj)
{
    jclass newExcCls;
    newExcCls = (*env)->FindClass(env, "java/lang/IllegalArgumentException");
    (*env)->ThrowNew(env, newExcCls, "thrown from C code");
}



















int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

