/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passingobject;

/**
 *
 * @author amank
 */

public class Passingobject {

    /**
     * @param args the command line arguments
     */
    static{
        System.load("C:\\Users\\amank\\OneDrive\\Documents\\NetBeansProjects\\passingobj\\dist\\passingobject.dll");
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SimpleClass sc = new SimpleClass();
        
        sc.call(sc);
    }
    private static native int call(int a);
}

