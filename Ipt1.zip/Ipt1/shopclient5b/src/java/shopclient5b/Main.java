/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopclient5b;

import ejbpkg.mysession5bRemote;
import javax.ejb.EJB;
import java.util.Scanner;

/**
 *
 * @author amank
 */
public class Main {
    @EJB
    private static mysession5bRemote mysession5b;
    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int ch,no;
        int i;
        Scanner sc=new Scanner(System.in);
        for(i=1;i<=2;i++)
        {
            System.out.println("Enter choice");
            ch=sc.nextInt();
            switch(ch)
            {
                case 2:
                    System.out.println("Enter number of items to buy from cart");
            no=sc.nextInt();
                   mysession5b.removeItem(no);
                    System.out.println("Total items in cart : "+mysession5b.stock());
                    break;
                    
                case 1:
                    System.out.println("Enter number of items to add in the cart");
            no=sc.nextInt();
                   mysession5b.addItem(no);
                    System.out.println("Total items in cart : "+mysession5b.stock());
                    break;
                default:
                    System.out.println("Enter correct choice");
           
            }
        }
    }
    
}
