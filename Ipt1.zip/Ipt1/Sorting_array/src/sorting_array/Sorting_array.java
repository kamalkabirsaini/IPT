/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting_array;
import java.util.Scanner;
/**
 *
 * @author amank
 */
public class Sorting_array {

    static{
    System.load("C:\\Users\\amank\\OneDrive\\Documents\\NetBeansProjects\\sorting_arrayc\\dist\\sortarraydll.dll");
}

    /**
     * @param args the command line arguments
     */
    public native int[] arraysorting(int[] array);
    static int array[];
    public static void main(String[] args) {
        // TODO code application logic here
        
         Scanner sc=new Scanner (System.in);
        System.out.println("enter the length of the array");
        int len=sc.nextInt();
        int[] anarray;
        int[] sorted_arr;
        int lenl;
        anarray = new int[len];
        for (int i=0;i<len;i++)
        {
            System.out.println("enter the number");
            anarray[i]=sc.nextInt();
        }
        Sorting_array obj=new Sorting_array();
        sorted_arr = obj.arraysorting(anarray); 
        for (int i=0;i<len;i++)
        {
            System.out.println(sorted_arr[i]);
        }
    }
    
    }
    


