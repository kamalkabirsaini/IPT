/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passingobject;

/**
 *
 * @author amank
 */
public class Passingobject {

    /**
     * @param args the command line arguments
     */
    static{
        System.load("C:\\Users\\amank\\OneDrive\\Documents\\NetBeansProjects\\passingobj\\dist\\passingobject.dll");
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SimpleClass sc = new SimpleClass();
        sc.count=10;
        
        System.out.println("Before Calling the Method \n"+sc.count);
        sc.increment();
        changecountvalue(sc);
        System.out.println("After Calling the Method \n"+sc.count);
    }
    private static native void changecountvalue(SimpleClass sc);
    
}
class SimpleClass 
{
     int count;
    public void increment(){
        count=count*10;
        System.out.println("Increment Method \n"+count);
        }
    }
    
